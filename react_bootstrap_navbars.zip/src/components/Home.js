import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Carousel } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import '../css/home.css';
import '../css/my.css';

const Home = () => {

  const [section1Visible, setSection1Visible] = useState(true);
  const [section2Visible, setSection2Visible] = useState(false);
  const [section3Visible, setSection3Visible] = useState(false);
  const [box1Visible, setBox1Visible] = useState(true);
  const [box2Visible, setBox2Visible] = useState(false);
  const [box3Visible, setBox3Visible] = useState(false);

  const handleSlideChange = (selectedIndex) => {

    // Reset section visibility when the slide changes
    setSection1Visible(false);
    setSection2Visible(false);
    setSection3Visible(false);
  
    // Reset box visibility
    setBox1Visible(false);
    setBox2Visible(false);
    setBox3Visible(false);
  
    if (selectedIndex === 0) {
      setTimeout(() => {
        setSection1Visible(true);
        setBox1Visible(true); // Show box1 for the first section
      }, 1000);
    }
  
    if (selectedIndex === 1) {
      setTimeout(() => {
        setSection2Visible(true);
        setBox2Visible(true); // Show box2 for the second section
      }, 1000);
    }
  
    if (selectedIndex === 2) {
      setTimeout(() => {
        setSection3Visible(true);
        setBox3Visible(true); // Show box3 for the third section
      }, 1000);
    }
  };

  return (
    <div className="wrapper">
      <div className="row11">
        <div className="carousel_tabs_cont">
          <div className="carouselcont">
            <Carousel fade onSelect={handleSlideChange}>
              <Carousel.Item>
                <img
                  className="b1"
                  src="/images/b1.jpg"
                  alt="First slide"
                />
                <Carousel.Caption></Carousel.Caption>
                {section1Visible && (
                  <motion.span
                    className="h2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    안녕하세요
                  </motion.span>
                )}
                    {box1Visible && (
                    <motion.div
                        className="box box1 box1_1"
                        initial={{ x: -1000, y: -1000, rotate: -90 }}
                        animate={
                        { x: -100, y: -100, rotate: -15, transition: { duration: 0.7 }}}
                    >
                    <img
                      className="box1i"
                      src="/images/box1.png"
                      alt="First slide"
                    />
                    </motion.div>
                    )}
                {box1Visible && (
                <motion.div
                    className="box box1 box1_2"
                    initial={{y: 1000, rotate: -90 }}
                    animate={{y: 0, rotate: 0 }}
                    transition={{ duration: 0.7 }}
                >
                    <span>에상스</span>
                </motion.div>
                )}
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src="/images/b2.jpg"
                  alt="Second slide"
                />
                <Carousel.Caption></Carousel.Caption>
                {section2Visible && (
                  <motion.span
                    className="h2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    감사해요
                  </motion.span>
                )}
                {box2Visible && (
                <motion.div
                    className="box box2 box2_1"
                    initial={{x: -1000, y: -1000, rotate: -90 }}
                    animate={{x: -100, y: -100, rotate: -15}}
                    transition={{ duration: 0.7 }}
                >
                    <span>에상스</span>
                </motion.div>
                )}
                {box2Visible && (
                <motion.div
                    className="box box2 box2_2"
                    initial={{y: 1000, rotate: -90 }}
                    animate={{y: 0, rotate: 0 }}
                    transition={{ duration: 0.7 }}
                >
                    <span>에상스</span>
                </motion.div>
                )}
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src="/images/b3.jpg"
                  alt="Third slide"
                />
                <Carousel.Caption></Carousel.Caption>
                {section3Visible && (
                  <motion.span
                    className="h2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    잘있어요
                  </motion.span>
                )}
                {box3Visible && (
                <motion.div
                    className="box box3 box3_1"
                    initial={{x: -1000, y: -1000, rotate: -90 }}
                    animate={{x: -100, y: -100, rotate: -15}}
                    transition={{ duration: 0.7 }}
                >
                    <span>에상스</span>
                </motion.div>
                )}
                {box3Visible && (
                <motion.div
                    className="box box3 box3_2"
                    initial={{y: 1000, rotate: -90 }}
                    animate={{y: 0, rotate: 0 }}
                    transition={{ duration: 0.7 }}
                >
                <span>에상스</span>
                </motion.div>
                )}
              </Carousel.Item>
            </Carousel>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;