import React from "react";
import Container from 'react-bootstrap/Container';

const Home = () => {
    return(        
        <div>
            <Container>
                <h1>홈</h1>
                <p>홈, 그 페이지는 가장 먼저 보여지는 페이지!</p>
            </Container>
        </div>
    );
};
export default Home;