import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';

class QnA extends Component {
    constructor(props){
        super(props);
        this.state = {
            moeniaId:"",
            moeniaTitle:"",
            moeniaContent:"",
            crud:props.match.params.crud,
        };
        if(this.state.crud !== "save"){
            this.getData();
        }
    }
    crud = () => {
        const{moeniaId, moeniaTitle, moeniaContent, crud} = 
        this.state;
        
        
        let crudType = "insertProcess.do";
        if(crud === "save"){
            crudType ="/view.do"
        }
        
        
        let form = new FormData();
        form.append("moeniaContent", moeniaContent);
        form.append("moeniaTitle", moeniaTitle);
        if(crud !== "save"){
            form.append("moeniaId",moeniaId);
        }
        
        axios
        .post(crudType, form)
        .then((res) => {
            alert("요청이 처리되었습니다!");
            this.props.history.push("/");
        })
        .catch((err) => alert("error : " + err.response.data.msg));
    }
    
    createCrudBtn(){
        const crud = this.state.crud;
        if(crud === "insertProcess.do"){
            return null;
        }else{
            
            return(
                <button onClick={()=> this.crud()}>상담하기</button>
                );
            }
        }

        createmoeniaIdTag() {
            const moeniaId = this.state.moeniaId;
            const crud = this.state.crud;
            
            // "moeniaId" 값을 숫자로 변환합니다.
            const moeniaIdNumber = parseInt(moeniaId, 10);
          
            if (!isNaN(moeniaIdNumber) && crud !== "save") {
              return (
                <input
                  type="hidden"
                  value={moeniaIdNumber}
                  readOnly
                />
              );
            } else {
              return null;
            }
          }

     
        
        getData(){
            axios.get("/insertProcess.do").then((res) => {
                const data = res.data;
                this.setState({
                    moeniaId: data.moeniaId,
                    moeniaTitle: data.moeniaTitle,
                    moeniaContent: data.moeniaContent,
                    
                });
            });
        }   


        render() {
            
            const moeniaTitle = this.state.moeniaTitle;
            const moeniaContent = this.state.moeniaContent;
            return (
                <Container>

    <h1>1:1 문의하기</h1>
    <input
      type='text'
      value={moeniaTitle || ''}
      onChange={(event) => this.setState({ moeniaTitle: event.target.value })}
    ></input>
    <br />
    <h3>내용</h3>
    <textarea
      rows="10"
      cols="20"
      value={moeniaContent || ''}
      onChange={(event) => this.setState({ moeniaContent: event.target.value })}
    ></textarea>
    <br /><br />
    {this.createCrudBtn()}
    <Link to="/">
      <button type='button'>취소</button>
    </Link>
  </Container>

  
        );
    }
}

export default QnA;