import { useEffect, useState } from "react";
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Footer from "./Footer";
import item2 from "../img/item2.png";

export default function About() {
    const [position, setPosition] = useState(0);
    function onScroll() {
        setPosition(window.scrollY);
    }
    useEffect(() => {
        window.addEventListener("scroll", onScroll);
        return () => {
            window.removeEventListener("scroll", onScroll);
        };
    }, []);

    return (
        <>
            <ReactBootstrapNavbars />
            <div className="wrapper">
                <div
                    className="bg bg1"
                    style={{
                        backgroundPositionY: position / 3,
                    }}
                >
                    <div>저희 회사는 편안한 분위기의 집을 조성하기 위해<br /> <br />최고의 인테리어 솔루션을 제공하는 전문 업체입니다.</div>
                </div>
                <div
                    className="desc"
                    style={{
                        transform: `translateX(${-position}px)`,
                    }}
                >
                    <div>다양한 벽지 디자인을 제공하여 고객들이 원하는 스타일을 찾을 수 있습니다. <br />  인테리어에 어울리는 벽지, 가구, 조명, 장식품 등 구경해보세요~</div>
                </div>
                <p
                    className="desc2"
                    style={{
                        transform: `translateX(${-position}px)`,
                    }}
                >
                </p>
                <p
                    className="desc3"
                    style={{
                        opacity: (position - 700) / 50
                    }}
                >
                </p>

                <p
                    className="bg bg2"
                    style={{
                        backgroundPositionY: position / -5,
                        opacity: (position - 1090) / 50,
                        textAlign: 'center'
                    }}
                >
                    <div>인테리어는 Moenia와 함께하세요</div>
                </p>
                <p
                    className="desc3"
                    style={{
                        opacity: (position - 1090) / 50,
                    }}
                />

                <img
                    src={item2}
                    className="item item_snow1"
                    alt=""
                    style={{
                        transform: `translateY(${position / 4}px)`,
                    }}
                />

            </div>
            <Footer />
        </>
    );
};