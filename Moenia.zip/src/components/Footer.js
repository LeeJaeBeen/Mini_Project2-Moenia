import React from "react";
import Container from 'react-bootstrap/Container';
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { fafacebook, fatwitter, fadribbble, falinkedin } from '@fortawesome/free-brands-svg-icons'
import "../css/common.css";
import "../css/footer.css";


// const url = "https://www.kcc.go.kr/user.do";

const Footer = () => {
    return(
        <div id="f_bg" >
            <Container>
                <div className="row f_top">
                    <div className="col-md-3 col-sm-6 col-xs-12 f_logo">
                        <a href="/"><img className="f_img" src='/img/f_logo.png' alt='로고이미지' ></img></a>
                    </div>
                    
                    <div className="footer__addr col-md-3 col-sm-6 col-xs-12">
                        <h1 className="footer__logo"><a href="/">Moenia</a></h1>
                    
                        <h2>주소</h2>
                        
                        <address>
                        서울특별시 구로구 경인로 557 삼영빌딩 4층
                        <br />

                        <a className="footer__btn" href="mailto:madola3813@gmail.com">Email Us</a>
                        </address>
                    </div>
                    
                    <ul className="footer__nav">
                        <li className="nav__item col-md-6 col-sm-6 col-xs-12">
                            <h2 className="nav__title">Site</h2>
                            
                            <ul className="nav__ul nav__ul--extra">
                                <li>
                                <a href="/About">회사소개</a>
                                </li>
                                
                                <li>
                                <a href="/Location">찾아오시는길</a>
                                </li>
                                
                                <li>
                                <a href="/product">상품소개</a>
                                </li>
                                
                                <li>
                                <a href="/QnA">자주묻는질문</a>
                                </li>
                                
                                <li>
                                <a href="/Consult">상담문의</a>
                                </li>

                                <li>
                                <a href="/Login">로그인</a>
                                </li>
                            </ul>
                        </li>
                    </ul>      
                    <ul className="footer__nav">                        
                        <li className="nav__item col-md-3 col-sm-6 col-xs-12">
                            <h2 className="nav__title">Info</h2>

                            <ul className="nav__ul">
                                <li>
                                <a href="{()=>false}">이용약관</a>
                                </li>

                                <li>
                                <a href="{()=>false}">개인정보처리방침</a>
                                </li>
                                    
                                <li>
                                <a href="{()=>false}">이용안내</a>
                                </li>
                            </ul>
                        </li>
                        {/* <li>
                            <button onClick={()=>{window.open(url)}} >웹사이트 바로가기</button>
                        </li>             */}
                    </ul>                     
                    <hr />
                    <div className="col-md-8 col-sm-6 col-xs-12 copy">
                        <p className="copyright-text">Copyright &copy; 2023 All Rights Reserved by&nbsp;
                        <a href="{()=>false}">Moenia</a>.
                        </p>
                    </div>
                    
                    <div className="col-md-4 col-sm-6 col-xs-12">
                        <ul className="social-icons">
                            <li><a className="facebook" href="{()=>false}"><i className="fa-brands fa-facebook-f"></i></a></li>
                            <li><a className="twitter" href="{()=>false}"><i className="fa-brands fa-twitter"></i></a></li>
                            <li><a className="dribbble" href="{()=>false}"><i className="fa-brands fa-dribbble"></i></a></li>
                            <li><a className="linkedin" href="{()=>false}"><i className="fa-brands fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>                    
                </div>    
                <br/>
            </Container>
        </div>
    );
};

export default Footer;