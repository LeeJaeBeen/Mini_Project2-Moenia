import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Footer from "./Footer";

class QnA extends Component {
  constructor(props) {
    super(props);
    this.state = {
      moeniaId: "1234",
      moeniaTitle: "",
      moeniaContent: ""
    };
  }
  crud = () => {
    const { moeniaId, moeniaTitle, moeniaContent } =
      this.state;

    let crudType = "insertProcess.do";

    let form = new FormData();
    form.append("moeniaContent", moeniaContent);
    form.append("moeniaTitle", moeniaTitle);
    form.append("moeniaId", moeniaId);

    axios
      .post(crudType, form)
      .then((res) => {
        alert("요청이 처리되었습니다!");
        this.props.history.push("/");
      })
      .catch((err) => alert("error : " + err.response.data.msg));
  }


  render() {

    const moeniaTitle = this.state.moeniaTitle;
    const moeniaContent = this.state.moeniaContent;
    return (
      <>
        <ReactBootstrapNavbars />
        <Container>
          <h1>1:1 문의하기</h1>
          <input
            type='text'
            value={moeniaTitle || ''}
            onChange={(event) => this.setState({ moeniaTitle: event.target.value })}
          ></input>
          <br />
          <h3>내용</h3>
          <textarea
            rows="10"
            cols="20"
            value={moeniaContent || ''}
            onChange={(event) => this.setState({ moeniaContent: event.target.value })}
          ></textarea>
          <br /><br />
          <button onClick={() => this.crud()}>상담하기</button>
          <Link to="/">
            <button type='button'>취소</button>
          </Link>
        </Container>
        <Footer />
      </>

    );
  }
}

export default QnA;