import React from "react";
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Footer from "./Footer";
import { Container } from "reactstrap";
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import '../css/product.css'

const kid = () => {
    return (
        <div>
            <ReactBootstrapNavbars />
            <Container>
                <Tabs
                    defaultActiveKey="Modern"
                    id="fill-tab-example"
                    className="mb-3"
                    fill
                >
                    <Tab eventKey="Kid" title="Kid">
                        <Row>
                            <Col lg className="kid1 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Daisy</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="kid2 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Giraffe</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="kid3 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Unicorn</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg className="kid4 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Under the Sea</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="kid5 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Toy Room</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="kid6 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Village Of Animals</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg className="kid7 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>My Fairytale Place</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="kid8 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>The World Is Mine</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="kid9 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Panda Bear</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                    </Tab>
                    <Tab eventKey="Nature" title="Nature">
                        <Row>
                            <Col lg className="Nature1 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Serenity Leaves</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Nature2 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Nature Indoors</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Nature3 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Jack and the Trees</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg className="Nature4 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Leopard Landscape</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Nature5 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Sophisticated Leaves</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Nature6 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Stroll Through The Woods</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg className="Nature7 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Metaverse Mountain</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Nature8 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Autumn</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Nature9 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>The Endless River</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                    </Tab>
                    <Tab eventKey="Modern" title="Modern">
                        <Row>
                            <Col lg className="Modern1 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Modern Living</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Modern2 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Pure Life</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Modern3 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Clean Charm</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg className="Modern4 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Cloud Classic</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Modern5 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>City Brick</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Modern6 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Canvas of the Future</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg className="Modern7 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Simple Life</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Modern8 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Luminant Star</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                            <Col lg className="Modern9 m20">
                                <div className="p_info">
                                    <p style={{ float: 'left' }}>Green Forest</p>
                                    <span style={{ float: 'right' }}>$59,00/m²</span>
                                </div>
                            </Col>
                        </Row>
                    </Tab>
                </Tabs>
            </Container>
            <Footer />
        </div>
    );
};
export default kid;