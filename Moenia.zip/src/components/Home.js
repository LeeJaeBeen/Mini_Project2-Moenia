import React, { useState,useEffect } from 'react';
import { motion } from 'framer-motion';
import { Carousel, Container } from 'react-bootstrap';
import { Heading, Text, Stack, SimpleGrid, Card, CardHeader, CardBody, CardFooter, Image} from '@chakra-ui/react'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import Aos from 'aos';

import Button from 'react-bootstrap/Button';
import ReactPlayer from "react-player";
import ReactBootstrapNavbars from './ReactBootstrapNavbars';
import Footer from './Footer';

import 'bootstrap/dist/css/bootstrap.css'; 
import "../css/aos.css";
import '../css/home.css';
import '../css/my.css';

const Home = () => {
  const [section1Visible, setSection1Visible] = useState(true);
  const [section2Visible, setSection2Visible] = useState(false);
  const [section3Visible, setSection3Visible] = useState(false);
  const [box1Visible, setBox1Visible] = useState(true);
  const [box2Visible, setBox2Visible] = useState(false);
  const [box3Visible, setBox3Visible] = useState(false);

  const handleSlideChange = (selectedIndex) => {

    // Reset section visibility when the slide changes
    setSection1Visible(false);
    setSection2Visible(false);
    setSection3Visible(false);
  
    // Reset box visibility
    setBox1Visible(false);
    setBox2Visible(false);
    setBox3Visible(false);
  
    if (selectedIndex === 0) {
      setTimeout(() => {
        setSection1Visible(true);
        setBox1Visible(true); // Show box1 for the first section
      }, 1000);
    }
  
    if (selectedIndex === 1) {
      setTimeout(() => {
        setSection2Visible(true);
        setBox2Visible(true); // Show box2 for the second section
      }, 1000);
    }
  
    if (selectedIndex === 2) {
      setTimeout(() => {
        setSection3Visible(true);
        setBox3Visible(true); // Show box3 for the third section
      }, 1000);
    }
  };

  useEffect(() => {
    Aos.init({duration: 1000});
  })
  const [activeTab, setActiveTab] = useState(0);

  return (
    <>
    <ReactBootstrapNavbars />
    <div className="wrapper">
        <div className="row11">
        {/* <Container> */}

            {/* Main 배너 1 */}
              <div className="carousel_tabs_cont main1">
                <div className="carouselcont">
                  <Carousel fade onSelect={handleSlideChange}>

                    {/* 첫번째 섹션 */}
                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src="/img/b1.jpg"
                        alt="Third slide"
                      />
                      <Carousel.Caption></Carousel.Caption>
                      {section1Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.5 }}
                        >
                          리빙
                        </motion.span>
                      )}
                      {section1Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="800" 
                          className="h2_1"
                        >              
                          <span data-aos="fade-up">LIFE IS LIVING</span>
                        </motion.span>
                      )}
                        {section1Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="1000" 
                          className="h2_2"
                        >
                          <sapn>공간, 삶, 그리고 변화<br/> 그릇된 인테리어 없이 완벽한 공간을 창조하며 우리의 일상을 미적 경험으로 만들어나갑니다. <br /> 감성과 기능을 조화롭게 결합시켜 우리의 삶을 더 풍요롭게 제공합니다. </sapn>
                        </motion.span>
                      )}
                        {section1Visible && (
                        <motion.div
                          data-aos="fade-up"
                          data-aos-delay="1100" 
                          className='player'                          
                        >
                          <span>자세히 보기</span>
                          <ReactPlayer
                            // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                            // url={process.env.PUBLIC_URL + '/video/sea.mp4'}
                            url='https://www.youtube.com/watch?v=ZQPRV7J41x4'
                            // 플레이어 크기(폭, 가로)
                            width='100%'
                            // 플레이어 크기(높이, 세로)
                            height='100%'
                            // 자동 실행 설정(true)
                            playing={false}                   
                            // 음소거 설정(true)
                            // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                            muted={false}
                            // 플레이어 컨트롤 노출 설정(true)
                            controls={false}
                            // 반복 재생 설정(true)
                            loop={true}
                          />
                        </motion.div>
                      )}                      
                      {box1Visible && (
                      <motion.div
                          className="box box3 box3_1"
                          initial={{x: -1000, y: -1000, rotate: -90 }}
                          animate={{x: -100, y: -100, rotate: -15}}
                          transition={{ duration: 0.7 }}
                      >
                          <img
                            className="boxi"
                            src="/img/box2.png"
                            alt="First slide"
                          />
                      </motion.div>
                      )}
                      {box1Visible && (
                      <motion.div
                          className="box box3 box3_2"
                          initial={{y: 1000, rotate: -90 }}
                          animate={{y: 0, rotate: 0 }}
                          transition={{ duration: 0.7 }}
                      >
                      <span data-aos="fade-up" data-aos-delay="500"  className='box1_span1'>리<br/>빙<br/></span>
                      </motion.div>
                      )}
                    </Carousel.Item>

                    {/* 2번쨰 섹션 */}
                    <Carousel.Item>
                      <img
                        className="b1"
                        src="/img/b2.jpg"
                        alt="First slide"
                      />
                      <Carousel.Caption></Carousel.Caption>
                      {section2Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2"
                          data-aos-delay="500" 
                        >
                          <sapn>에상스</sapn>
                        </motion.span>
                      )}
                      {section2Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2_1"
                          data-aos-delay="600" 
                        >              
                          <span data-aos="fade-up">The Premium Life with ESSENCE</span>
                        </motion.span>
                      )}
                        {section2Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="800" 
                          className="h2_2"
                        >
                          <sapn>아름다움, 스타일, 그리고 품격 <br /> 우리의 공간은 더 이상 단순한 공간이 아닙니다. <br />우리 삶을 더 특별하게 만들어주는 곳이며, 우리의 품격을 높여주는 공간입니다.</sapn>
                        </motion.span>
                      )}
                      {section2Visible && (
                        <motion.div
                          data-aos="fade-up"
                          data-aos-delay="1100" 
                          className='player'                          
                        >
                          <span>자세히 보기</span>
                          <ReactPlayer
                            // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                            // url={process.env.PUBLIC_URL + '/video/sea.mp4'}
                            url='https://www.youtube.com/watch?v=VhY65lNZvQY'
                            // 플레이어 크기(폭, 가로)
                            width='100%'
                            // 플레이어 크기(높이, 세로)
                            height='100%'
                            // 자동 실행 설정(true)
                            playing={false}                   
                            // 음소거 설정(true)
                            // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                            muted={false}
                            // 플레이어 컨트롤 노출 설정(true)
                            controls={false}
                            // 반복 재생 설정(true)
                            loop={true}
                          />
                        </motion.div>
                      )}   
                          {box2Visible && (
                          <motion.div
                              className="box box1 box1_1"
                              initial={{ x: -1000, y: -1000, rotate: -90 }}
                              animate={
                              { x: -100, y: -100, rotate: -15, transition: { duration: 0.7 }}}
                          >
                          <img
                            className="boxi"
                            src="/img/box1.png"
                            alt="First slide"
                          />
                          </motion.div>
                          )}
                      {box2Visible && (
                      <motion.div
                          className="box box1 box1_2"
                          initial={{y: 1000, rotate: -90 }}
                          animate={{y: 0, rotate: 0 }}
                          transition={{ duration: 1 }}
                      >
                          <span data-aos="fade-up" data-aos-delay="500"  className='box1_span1'>에<br />상<br />스</span>
                      </motion.div>
                      )}
                    </Carousel.Item>

                    {/* 3번째 섹션 */}
                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src="/img/b3.jpg"
                        alt="Second slide"
                      />
                      <Carousel.Caption></Carousel.Caption>
                      {section3Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.5 }}
                        >
                          아이리스
                        </motion.span>
                      )}
                      {section3Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2_1"
                          data-aos-delay="600" 
                        >              
                          <span data-aos="fade-up">세상에서 가장 쉬운 벽지 코디가이드</span>
                        </motion.span>
                      )}
                      {section3Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="800" 
                          className="h2_2"
                        >
                          <sapn>벽지 인테리어 고민하지말고 쉽게 해보세요<br /> 아이리스가 꿈의 공간을 제공합니다. <br /> 아이리스는 소비자가 원하는 맞춤형 코디를 해줍니다.</sapn>
                        </motion.span>
                      )}
                      {section3Visible && (
                        <motion.div
                          data-aos="fade-up"
                          data-aos-delay="1100" 
                          className='player'                          
                        >
                        <span>자세히 보기</span>
                          <ReactPlayer
                            // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                            // url={process.env.PUBLIC_URL + '/video/sea.mp4'}
                            url='https://www.youtube.com/watch?v=O5sre-RGuvY'
                            // 플레이어 크기(폭, 가로)
                            width='100%'
                            // 플레이어 크기(높이, 세로)
                            height='100%'
                            // 자동 실행 설정(true)
                            playing={false}                   
                            // 음소거 설정(true)
                            // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                            muted={false}
                            // 플레이어 컨트롤 노출 설정(true)
                            controls={false}
                            // 반복 재생 설정(true)
                            loop={true}
                          />
                        </motion.div>
                      )}   
                      {box3Visible && (
                      <motion.div
                          className="box box2 box2_1"
                          initial={{x: -1000, y: -1000, rotate: -90 }}
                          animate={{x: -100, y: -100, rotate: -15}}
                          transition={{ duration: 0.7 }}
                      >
                      <img
                            className="boxi"
                            src="/img/box3.png"
                            alt="First slide"
                          />
                      </motion.div>
                      )}
                      {box3Visible && (
                      <motion.div
                          className="box box2 box2_2"
                          initial={{y: 1000, rotate: -90 }}
                          animate={{y: 0, rotate: 0 }}
                          transition={{ duration: 0.7 }}
                      >
                      <span data-aos="fade-up" data-aos-delay="500"  className='box1_span1'>아<br />이<br />리<br />스</span>
                      </motion.div>
                      )}
                    </Carousel.Item>
                  </Carousel>
                </div>
              </div>
        </div>
        


            <div className='main2'>
              <div className='main2_t' data-aos="fade-up" data-aos-delay="300">
                <span>우리는 다양한 인테리어 디자인을 통해 자신만의 공간을 만들어 드립니다.</span><br/>
                <span>다양한 디자인 옵션을 통해 고객들의 선호와 스타일을 반영하여 </span> <br/>
                <span>각자의 특별한 공간을 창조합니다.</span>            
                
              </div>
              <div className='main2_i'>
                <SimpleGrid spacing={100} templateColumns='repeat(auto-fill, minmax(25%, 1fr))' className='card'>
                    <Card data-aos="fade-up" data-aos-delay="500" className = 'card1'>  
                      <CardHeader>
                        <Heading size='md'>
                        <img                      
                        className="b1"
                        src="/img/modern6.jpg"
                        style={{ height: '40vw' }}
                      />
                        </Heading>
                      </CardHeader>
                      <CardFooter className='cardF'>
                        <Button className='cardBtn' href='/product'>자세히 보기</Button>
                      </CardFooter>
                    </Card>
                    <Card data-aos="fade-up" data-aos-delay="800" className = 'card2'>
                      <CardHeader>
                        <Heading size='md'>
                        <img
                        className="b1"
                        src="/img/modern8.jpg"
                        style={{ height: '40vw' }}
                      />
                        </Heading>
                      </CardHeader>
                      <CardFooter className='cardF'>
                        <Button className='cardBtn'>자세히 보기</Button>
                      </CardFooter>
                    </Card>
                    <Card data-aos="fade-up" data-aos-delay="1000" className = 'card3'>
                      <CardHeader>
                        <Heading size='md'>
                        <img
                        className="b1"
                        src="/img/Nature7.jpg"
                        style={{ height: '40vw' }}
                      />
                        </Heading>
                      </CardHeader>
                      <CardFooter className='cardF'>
                        <Button className='cardBtn'>자세히 보기</Button>
                      </CardFooter>
                    </Card>
                  </SimpleGrid>
              </div>
            </div>



            <Container>
            <div className='main3'>
              <span className='main3_t'>제품 소개</span>   
              <Tabs
                defaultActiveKey="profile"
                id="justify-tab-example"
                className="mb-3"
                justify
              >
                <Tab eventKey="home" title="Home" className='mt3'>
                  <div className='main3_i'
                  >
                  <img                        
                        src="/img/modern2.jpg"
                        alt="First slide"
                      />
                  </div>
                  <div className='main3_te'
                  >  
                      <h3>독창적 아름다움, 한발 앞선 디자인으로 공간의 가치를 높이다.</h3>
                      <hr />
                      <span>
                        환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                      </span>
                  </div>
                  {/* <div className='main3_ti'>

                  </div> */}
                </Tab>
                <Tab eventKey="profile" title="Profile" className='mt3'>
                  <div className='main3_i'>
                    <img                        
                          src='/img/modern3.jpg'
                          alt="Second slide"
                        />
                    </div>
                    <div className='main3_te'>  
                        <h3>Color Lifestyle! 심플함에 컬러를 더하다.</h3>
                        <hr />
                        <span>
                          미니멀한 감성으로 현대적인 세련미를 대표하는 베이직플러스는 제일벽지의 대표 실크 무지 벽지. 
                          다양한 질감과 텍스쳐를 특징으로 다채로운 컬러스펙트럼을 자랑합니다. 
                          원하는 컬러와 소재를 선택해 나만의 공간을 꾸밀 수 있고 항곰팡이 기능성을 통해 보다 안전한 공간을 선사합니다.    
                        </span>
                    </div>
                    {/* <div className='main3_ti'>

                    </div> */}
                </Tab>
                <Tab eventKey="longer-tab" title="Loooonger Tab" className='mt3'>
                  <div className='main3_i'>
                    <img                        
                          src="/img/Modern5.jpg"
                          alt="Third slide"
                        />
                    </div>
                    <div className='main3_te'>  
                        <h3>마음까지 편안한 안심공간, 친환경 기능성 방염벽지</h3>
                        <hr />
                        <span>
                          국가 공인 시험검사 기관인 "한국소방산업기술원"이 인증하는 방염마크를 획득한 기능성 실크벽지 더 레드 플러스. 
                          화재 발생 시에 불에 잘 타지 않아 종이와 PVC에서 발출되는 다량의 매연과 유독가스를 억제시킴으로서 귀중한 인명과 재산을 보호합니다.
                        </span>
                    </div>
                    {/* <div className='main3_ti'>

                    </div> */}
                </Tab>
                <Tab eventKey="contact" title="Contact" className='mt3'> 
                  <div className='main3_i'>
                    <img                        
                          src="/img/Nature8.jpg"
                          alt="Fourth slide"
                        />
                    </div>
                    <div className='main3_te'>  
                        <h3>건강한 소재로 만든 편백나무벽지</h3>
                        <hr />
                        <span>
                          나무는 국내에서 자란 편백나무, 향나무, 녹차, 쑥 등을 주원료로 운모, 홍화, 울금, 정향, 쪽, 향백 등 
                          인체에 유익한 천연소재를 더하여 만든 벽지입니다.
                        </span>
                    </div>
                    {/* <div className='main3_ti'>

                    </div> */}
                </Tab>
              </Tabs>
            </div>
        </Container>
    </div>
    <Footer />       
    </>
  );
};

export default Home;