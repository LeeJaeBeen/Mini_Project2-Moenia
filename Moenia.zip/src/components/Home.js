import React from "react";
import Container from 'react-bootstrap/Container';
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Footer from "./Footer";

const Home = () => {
    return (
        <div>
            <Container>
                <ReactBootstrapNavbars />
                <h1>홈</h1>
                <p>홈, 그 페이지는 가장 먼저 보여지는 페이지!</p>
            </Container>
            <Footer />
        </div>
    );
};
export default Home;