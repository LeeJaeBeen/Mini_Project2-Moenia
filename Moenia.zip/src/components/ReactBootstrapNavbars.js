import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
import "../css/common.css";
// react-bootstrap/Navbar
// https://react-bootstrap.netlify.app/docs/components/navbar/

function ReactBootstrapNavbars() {
  return (
    <Navbar bg="white" expand="lg">
      <Container>
        <Navbar.Brand href="/" className='logo'><img src='/img/logo.png' alt='로고이미지' /></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mx-auto font align-items-center">
            <Nav.Link className='nav_margin' href="/About"><p>회사소개</p></Nav.Link>
            <NavDropdown title={<span className='nav_span'>상품소개</span>} id="basic-nav-dropdown">
              <div className='eng'>
                <NavDropdown.Item className='nav_item' href="/notice"><p>Kids</p></NavDropdown.Item>
                <NavDropdown.Item className='nav_item' href="/freeboard"><p>Nature</p></NavDropdown.Item>
                <NavDropdown.Item className='nav_item' href="/communityboard"><p>Modern</p></NavDropdown.Item>
              </div>
            </NavDropdown>
            <Nav.Link className='nav_margin free' href="/board"><p>자유게시판</p></Nav.Link>
            <Nav.Link className='nav_margin' href="/Location"><p>찾아오시는길</p></Nav.Link>
          </Nav>
          <Button className='login_btn' variant="outline-secondary" href='/Login'>로그인</Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default ReactBootstrapNavbars;