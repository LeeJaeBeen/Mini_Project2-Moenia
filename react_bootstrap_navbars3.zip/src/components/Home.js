import React, { useState,useEffect } from 'react';
import { motion } from 'framer-motion';
import { Carousel, Container } from 'react-bootstrap';
import { Heading, Text, Stack, SimpleGrid, Card, CardHeader, CardBody, CardFooter, Image} from '@chakra-ui/react'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import Aos from 'aos';

import Button from 'react-bootstrap/Button';
import ReactPlayer from "react-player";


import 'bootstrap/dist/css/bootstrap.css'; 
import "../css/aos.css";
import '../css/home.css';
import '../css/my.css';

const Home = () => {
  const [section1Visible, setSection1Visible] = useState(true);
  const [section2Visible, setSection2Visible] = useState(false);
  const [section3Visible, setSection3Visible] = useState(false);
  const [box1Visible, setBox1Visible] = useState(true);
  const [box2Visible, setBox2Visible] = useState(false);
  const [box3Visible, setBox3Visible] = useState(false);

  const handleSlideChange = (selectedIndex) => {

    // Reset section visibility when the slide changes
    setSection1Visible(false);
    setSection2Visible(false);
    setSection3Visible(false);
  
    // Reset box visibility
    setBox1Visible(false);
    setBox2Visible(false);
    setBox3Visible(false);
  
    if (selectedIndex === 0) {
      setTimeout(() => {
        setSection1Visible(true);
        setBox1Visible(true); // Show box1 for the first section
      }, 1000);
    }
  
    if (selectedIndex === 1) {
      setTimeout(() => {
        setSection2Visible(true);
        setBox2Visible(true); // Show box2 for the second section
      }, 1000);
    }
  
    if (selectedIndex === 2) {
      setTimeout(() => {
        setSection3Visible(true);
        setBox3Visible(true); // Show box3 for the third section
      }, 1000);
    }
  };

  useEffect(() => {
    Aos.init({duration: 1000});
  })
  const [activeTab, setActiveTab] = useState(0);

  return (
    
    <div className="wrapper">
        <div className="row11">
        {/* <Container> */}

            {/* Main 배너 1 */}
              <div className="carousel_tabs_cont main1">
                <div className="carouselcont">
                  <Carousel fade onSelect={handleSlideChange}>

                    {/* 첫번째 섹션 */}
                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src="/images/b1.jpg"
                        alt="Third slide"
                      />
                      <Carousel.Caption></Carousel.Caption>
                      {section1Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.5 }}
                        >
                          리빙
                        </motion.span>
                      )}
                      {section1Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="800" 
                          className="h2_1"
                        >              
                          <span data-aos="fade-up">LIFE IS LIVING</span>
                        </motion.span>
                      )}
                        {section1Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="1000" 
                          className="h2_2"
                        >
                          <sapn>공간, 삶, 그리고 변화<br/> 그릇된 인테리어 없이 완벽한 공간을 창조하며 우리의 일상을 미적 경험으로 만들어나갑니다. <br /> 감성과 기능을 조화롭게 결합시켜 우리의 삶을 더 풍요롭게 제공합니다. </sapn>
                        </motion.span>
                      )}
                        {section1Visible && (
                        <motion.div
                          data-aos="fade-up"
                          data-aos-delay="1100" 
                          className='player'                          
                        >
                          <span>자세히 보기</span>
                          <ReactPlayer
                            // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                            // url={process.env.PUBLIC_URL + '/video/sea.mp4'}
                            url='https://www.youtube.com/watch?v=6RQ-bBdASvk'
                            // 플레이어 크기(폭, 가로)
                            width='100%'
                            // 플레이어 크기(높이, 세로)
                            height='100%'
                            // 자동 실행 설정(true)
                            playing={false}                   
                            // 음소거 설정(true)
                            // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                            muted={false}
                            // 플레이어 컨트롤 노출 설정(true)
                            controls={false}
                            // 반복 재생 설정(true)
                            loop={true}
                          />
                        </motion.div>
                      )}                      
                      {box1Visible && (
                      <motion.div
                          className="box box3 box3_1"
                          initial={{x: -1000, y: -1000, rotate: -90 }}
                          animate={{x: -100, y: -100, rotate: -15}}
                          transition={{ duration: 0.7 }}
                      >
                          <img
                            className="boxi"
                            src="/images/box2.png"
                            alt="First slide"
                          />
                      </motion.div>
                      )}
                      {box1Visible && (
                      <motion.div
                          className="box box3 box3_2"
                          initial={{y: 1000, rotate: -90 }}
                          animate={{y: 0, rotate: 0 }}
                          transition={{ duration: 0.7 }}
                      >
                      <span data-aos="fade-up" data-aos-delay="500"  className='box1_span1'>리<br/>빙<br/></span>
                      </motion.div>
                      )}
                    </Carousel.Item>

                    {/* 2번쨰 섹션 */}
                    <Carousel.Item>
                      <img
                        className="b1"
                        src="/images/b2.jpg"
                        alt="First slide"
                      />
                      <Carousel.Caption></Carousel.Caption>
                      {section2Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2"
                          data-aos-delay="500" 
                        >
                          <sapn>에상스</sapn>
                        </motion.span>
                      )}
                      {section2Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2_1"
                          data-aos-delay="600" 
                        >              
                          <span data-aos="fade-up">The Premium Life with ESSENCE</span>
                        </motion.span>
                      )}
                        {section2Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="800" 
                          className="h2_2"
                        >
                          <sapn>아름다움, 스타일, 그리고 품격 <br /> 우리의 공간은 더 이상 단순한 공간이 아닙니다. <br />우리 삶을 더 특별하게 만들어주는 곳이며, 우리의 품격을 높여주는 공간입니다.</sapn>
                        </motion.span>
                      )}
                      {section2Visible && (
                        <motion.div
                          data-aos="fade-up"
                          data-aos-delay="1100" 
                          className='player'                          
                        >
                          <span>자세히 보기</span>
                          <ReactPlayer
                            // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                            // url={process.env.PUBLIC_URL + '/video/sea.mp4'}
                            url='https://www.youtube.com/watch?v=sVTy_wmn5SU'
                            // 플레이어 크기(폭, 가로)
                            width='100%'
                            // 플레이어 크기(높이, 세로)
                            height='100%'
                            // 자동 실행 설정(true)
                            playing={false}                   
                            // 음소거 설정(true)
                            // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                            muted={false}
                            // 플레이어 컨트롤 노출 설정(true)
                            controls={false}
                            // 반복 재생 설정(true)
                            loop={true}
                          />
                        </motion.div>
                      )}   
                          {box2Visible && (
                          <motion.div
                              className="box box1 box1_1"
                              initial={{ x: -1000, y: -1000, rotate: -90 }}
                              animate={
                              { x: -100, y: -100, rotate: -15, transition: { duration: 0.7 }}}
                          >
                          <img
                            className="boxi"
                            src="/images/box1.png"
                            alt="First slide"
                          />
                          </motion.div>
                          )}
                      {box2Visible && (
                      <motion.div
                          className="box box1 box1_2"
                          initial={{y: 1000, rotate: -90 }}
                          animate={{y: 0, rotate: 0 }}
                          transition={{ duration: 1 }}
                      >
                          <span data-aos="fade-up" data-aos-delay="500"  className='box1_span1'>에<br />상<br />스</span>
                      </motion.div>
                      )}
                    </Carousel.Item>

                    {/* 3번째 섹션 */}
                    <Carousel.Item>
                      <img
                        className="d-block w-100"
                        src="/images/b3.jpg"
                        alt="Second slide"
                      />
                      <Carousel.Caption></Carousel.Caption>
                      {section3Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.5 }}
                        >
                          아이리스
                        </motion.span>
                      )}
                      {section3Visible && (
                        <motion.span
                          data-aos="fade-up"
                          className="h2_1"
                          data-aos-delay="600" 
                        >              
                          <span data-aos="fade-up">세상에서 가장 쉬운 벽지 코디가이드</span>
                        </motion.span>
                      )}
                      {section3Visible && (
                        <motion.span
                          data-aos="fade-up"
                          data-aos-delay="800" 
                          className="h2_2"
                        >
                          <sapn>벽지 인테리어 고민하지말고 쉽게 해보세요<br /> 아이리스가 꿈의 공간을 제공합니다. <br /> 아이리스는 소비자가 원하는 맞춤형 코디를 해줍니다.</sapn>
                        </motion.span>
                      )}
                      {section3Visible && (
                        <motion.div
                          data-aos="fade-up"
                          data-aos-delay="1100" 
                          className='player'                          
                        >
                        01<span>자세히 보기</span>
                          <ReactPlayer
                            // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                            // url={process.env.PUBLIC_URL + '/video/sea.mp4'}
                            url='https://www.youtube.com/watch?v=Os_heh8vPfs'
                            // 플레이어 크기(폭, 가로)
                            width='100%'
                            // 플레이어 크기(높이, 세로)
                            height='100%'
                            // 자동 실행 설정(true)
                            playing={false}                   
                            // 음소거 설정(true)
                            // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                            muted={false}
                            // 플레이어 컨트롤 노출 설정(true)
                            controls={false}
                            // 반복 재생 설정(true)
                            loop={true}
                          />
                        </motion.div>
                      )}   
                      {box3Visible && (
                      <motion.div
                          className="box box2 box2_1"
                          initial={{x: -1000, y: -1000, rotate: -90 }}
                          animate={{x: -100, y: -100, rotate: -15}}
                          transition={{ duration: 0.7 }}
                      >
                      <img
                            className="boxi"
                            src="/images/box3.png"
                            alt="First slide"
                          />
                      </motion.div>
                      )}
                      {box3Visible && (
                      <motion.div
                          className="box box2 box2_2"
                          initial={{y: 1000, rotate: -90 }}
                          animate={{y: 0, rotate: 0 }}
                          transition={{ duration: 0.7 }}
                      >
                      <span data-aos="fade-up" data-aos-delay="500"  className='box1_span1'>아<br />이<br />리<br />스</span>
                      </motion.div>
                      )}
                    </Carousel.Item>
                  </Carousel>
                </div>
              </div>
        </div>
            <div className='main2'>
              <div className='main2_t' data-aos="fade-up" data-aos-delay="300">
                <span>We create bespoke interiors from the</span><br/>
                <span>widest palette of possibilites that instantly</span> <br/>
                <span>become our client's favorite places</span>            
              </div>
              <div className='main2_i'>
                <SimpleGrid spacing={100} templateColumns='repeat(auto-fill, minmax(25%, 1fr))' className='card'>
                    <Card data-aos="fade-up" data-aos-delay="500" className = 'card1'>  
                      <CardHeader>
                        <Heading size='md'>
                        <img
                        className="b1"
                        src="/images/box1.png"
                        alt="First slide"
                      />
                        </Heading>
                      </CardHeader>
                      <CardFooter className='cardF'>
                        <Button className='cardBtn'>자세히 보기</Button>
                      </CardFooter>
                    </Card>
                    <Card data-aos="fade-up" data-aos-delay="800" className = 'card2'>
                      <CardHeader>
                        <Heading size='md'>
                        <img
                        className="b1"
                        src="/images/box1.png"
                        alt="First slide"
                      />
                        </Heading>
                      </CardHeader>
                      <CardFooter className='cardF'>
                        <Button className='cardBtn'>자세히 보기</Button>
                      </CardFooter>
                    </Card>
                    <Card data-aos="fade-up" data-aos-delay="1000" className = 'card3'>
                      <CardHeader>
                        <Heading size='md'>
                        <img
                        className="b1"
                        src="/images/box1.png"
                        alt="First slide"
                      />
                        </Heading>
                      </CardHeader>
                      <CardFooter className='cardF'>
                        <Button className='cardBtn'>자세히 보기</Button>
                      </CardFooter>
                    </Card>
                  </SimpleGrid>
              </div>
            </div>



            <Container>
            <div className='main3'>
              <span className='main3_t'>제품 소개</span>   
              <Tabs
                defaultActiveKey="profile"
                id="justify-tab-example"
                className="mb-3"
                justify
              >
                <Tab eventKey="home" title="Home" className='mt3'>
                  <div className='main3_i'
                  >
                  <img                        
                        src="/images/box1.png"
                        alt="First slide"
                      />
                  </div>
                  <div className='main3_te'
                  >  
                      <h3>독창적 아름다움, 한발 앞선 디자인으로 공간의 가치를 높이다.</h3>
                      <hr />
                      <span>
                        환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                      </span>
                  </div>
                </Tab>
                <Tab eventKey="profile" title="Profile" className='mt3'>
                  <div className='main3_i'>
                    <img                        
                          src="/images/box1.png"
                          alt="First slide"
                        />
                    </div>
                    <div className='main3_te'>  
                        <h3>독창적 아름다움, 한발 앞선 디자인으로 공간의 가치를 높이다.</h3>
                        <hr />
                        <span>
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        </span>
                    </div>
                </Tab>
                <Tab eventKey="longer-tab" title="Loooonger Tab" className='mt3'>
                  <div className='main3_i'>
                    <img                        
                          src="/images/box1.png"
                          alt="First slide"
                        />
                    </div>
                    <div className='main3_te'>  
                        <h3>독창적 아름다움, 한발 앞선 디자인으로 공간의 가치를 높이다.</h3>
                        <hr />
                        <span>
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        </span>
                    </div>
                </Tab>
                <Tab eventKey="contact" title="Contact" className='mt3'> 
                  <div className='main3_i'>
                    <img                        
                          src="/images/box1.png"
                          alt="First slide"
                        />
                    </div>
                    <div className='main3_te'>  
                        <h3>독창적 아름다움, 한발 앞선 디자인으로 공간의 가치를 높이다.</h3>
                        <hr />
                        <span>
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                          환경부인증 친환경벽지. 우리 가족을 위한 이유있는 선택.
                        </span>
                    </div>
                </Tab>
              </Tabs>
            </div>
        </Container>
    </div>
  );
};

export default Home;