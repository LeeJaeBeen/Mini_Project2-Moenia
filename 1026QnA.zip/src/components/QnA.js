import React from "react";
import Container from 'react-bootstrap/Container';
import Accordion from 'react-bootstrap/Accordion';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import '../css/qna.css';

// https://react-bootstrap.netlify.app/docs/components/accordion/

function QnA() {
  return (
    <>
    <Container>
    <div className="box">
    <Tabs

      defaultActiveKey="카테고리"
      id="uncontrolled-tab-example"
      className="mb-3"
    >
      
      <Tab eventKey="카테고리" title="카테고리">
      
    <Accordion defaultActiveKey=" ">
      <Accordion.Item eventKey="0">
        <Accordion.Header>카테고리별 이미지 샘플은 어떻게 신청하나요?</Accordion.Header>
        <Accordion.Body>
        Moenia는 고객님의 맞춤 시공을 위해 집에서 편하게 벽지를 선택할 수 있도록
        벽지 원단 샘플 서비스를 제공해드리고 있습니다.
        <br></br>
        샘플은 A4 사이즈로 제공되며, 발송 후 지역에 따라 3~5일 정도 소요될 예정입니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>우드 필름과 솔리드 필름 차이가 무엇인가요?</Accordion.Header>
        <Accordion.Body>
        - 솔리드 필름은 무늬가 없는 필름입니다. 깔끔한 느낌을 주지만 시공대상의 상태가 좋지 않거나 살면서 손상이 가는 경우 티가 잘 납니다.
        <br></br>
        - 우드 필름은 나뭇결로 무늬가 있는 필름입니다. 시공대상의 상태가 좋지 않거나 생활하시며 손상이 가는 경우에도 어느 정도 커버가 가능해 티가 잘 나지 않습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header>실크벽지와 합지벽지 차이점이 무엇인가요?</Accordion.Header>
        <Accordion.Body>    
        - 합지벽지는 벽지와 벽지 사이를 겹쳐서 시공하기 때문에 이음매가 보입니다.
        <br></br>
        - 실크벽지는 벽지와 벽지 사이를 맞대어 시공하기 때문에 이음매가 거의 보이지 않습니다
        <br></br>
        합지벽지는 종이 벽지이며 실크는 종이 벽지에 코팅이 되어 있습니다.
        기본적으로 벽지 수명이 실크벽지가 더 오래 갑니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header>질문 #4</Accordion.Header>
        <Accordion.Body>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header>사용하시는 벽지가 친환경 제품인가요?</Accordion.Header>
        <Accordion.Body>
        각 벽지 제조사별로 친환경인증을 받고 나오는 제품만 취급하고 있습니다.
        안심하고 사용하셔도 좋습니다.
        </Accordion.Body>
      </Accordion.Item>
      </Accordion>
      </Tab>

   
      <Tab eventKey="결제 및 환불 관련" title="결제 관련">
      <Accordion defaultActiveKey="">
      <Accordion.Item eventKey="0">
        <Accordion.Header>계약은 어떻게 진행되나요?</Accordion.Header>
        <Accordion.Body>
          고객님에게 발행된 모바일 견적서의 고객 확인 사항을 꼼꼼히 확인 후 시공을 진행하기 위해 모두 동의해주시면 계약금 입금 정보를 확인할 수 있습니다.
          <br></br>
          계약금이 입금 완료되어야 정상적으로 계약이 완료 됩니다. 순서대로 시공일정이 확정되니 입금이 늦어질 경우 원하시는 일정에 시공이 불가할 수 있습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>현금영수증 발행 가능한가요?</Accordion.Header>
        <Accordion.Body>
         Moenia의 모든 견적에는 부가세가 포함되어 있습니다.(2023년 10월 기준)
         <br></br>
         전액 현금영수증 발행이 가능합니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header>시공 취소 관련 환불 안내</Accordion.Header>
        <Accordion.Body>
        시공일로부터 8~15일(시공마다 상이) 이상이 여유가 있는 경우, 시공 취소나 일정 변경은 자유롭게 가능합니다.
        다만, 하단에 기재된 기준에 해당할 경우 위약금이 발생합니다
        (주말 및 법정 공휴일 제외)
        - 시공일 14일 전 오후 6시까지 : 계약금 100% 환불
        - 시공일 14일 전 오후 6시 이후 : 계약금 환불 불가
        시공일 14일 전 취소를 원하실 경우 환불은 가능하지만 이미 실측이 진행되었을 경우 실측 비용은 환불 불가합니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header>시공 변경 및 취소 가능 시간</Accordion.Header>
        <Accordion.Body>
        (주말, 법정 공휴일 제외)

        - 영업일 내 오전 09시 – 오후 06시

        오직 전화 상담을 통한 예약 및 취소/변경 방식만 가능합니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header>시공이 불가할 경우의 환불</Accordion.Header>
        <Accordion.Body>
        1. 고객확인서에 기재된 내용과 현장상황이 상이하여 시공이 불가할 경우, 시공이 취소될 수 있으며, 이 경우 계약금 환불이 불가합니다.

        2. 기후변화와 천재지변 등의 이유로 시공이 취소될 수 있습니다. 이 경우 일정 변경 혹은 계약금 전액 환불이 가능합니다.
        </Accordion.Body>
      </Accordion.Item>
     </Accordion>
      </Tab>

      <Tab eventKey="인테리어 시공관련" title="환불 관련">
      <Accordion defaultActiveKey="">
      <Accordion.Item eventKey="0">
        <Accordion.Header>인테리어 견적은 어떻게 받나요?</Accordion.Header>
        <Accordion.Body>
        인테리어 견적은 시공대상의 굴곡이나 크기, 상태에 따라 시공 견적이 상이합니다.
        그렇기 때문에 필수적으로 사진을 전달받아야 견적이 가능합니다.
        고객센터로 시공 범위의 사진을 전달해주시면 정확한 견적을 전달 드립니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>거주 중/짐이 있는 경우에도 인테리어가 가능한가요?</Accordion.Header>
        <Accordion.Body>
        거주 중/짐이 있는 경우 인원이 추가되어 도배가 진행됩니다.
        잔짐(가구 위, 가구 안 등)은 모두 시공범위 제외구역(베란다, 화장실 등)으로 미리 치워주셔야 가구를 옮겨가며 시공 할 수 있습니다.
        간혹 짐이 많은 경우 시공이 불가한 경우도 있으니 고객센터로 짐 사진을 미리 보내주세요.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header>기존에 있던 필름, 벽지는 전부 제거하고 시공하나요?</Accordion.Header>
        <Accordion.Body>
        1. 필름 : 일반적으로 필름 시공은 덧방 시공이 원칙입니다. 하지만 시공 품질을 저하시킬 수 있는 부분을 선택적으로 제거합니다.
        2. 벽지 : 기존 벽지가 실크인 경우 벽지의 겉지를 모두 제거하고 도배합니다.
                기존 벽지가 합지인 경우 시공 품질을 저하시킬 수 있는 부분을 선택적으로 제거합니다.
                벽지를 제거하지 않는 경우는
                - 벽지를 뜯었을 때 벽체의 노후화로 인해 시멘트가 같이 뜯겨나오는 경우
                - 기존 벽지가 잘 붙어 있을 때 덧방이 벽면 상태를 완화해 품질이 더 좋은 경우 등이 있습니다.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header>질문 #4</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header>질문 #5</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      </Accordion>
      </Tab>

      <Tab eventKey="기타 / 공통" title="기타 / 공통">
      <Accordion defaultActiveKey="">
      <Accordion.Item eventKey="0">
        <Accordion.Header>주말, 공휴일에도 작업이 가능한가요?</Accordion.Header>
        <Accordion.Body>
         현재 소음이 적게 발생하는 작업 같은 경우는 일요일, 공휴일(명절제외)도 시공은 가능합니다.
         가능 시공 안내 : 벽지, 필름
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>인테리어 시공시 주의해야할 점이 따로 있을까요?</Accordion.Header>
        <Accordion.Body>
        1. 귀중품은 전부 치워주세요. 분실의 경우 책임지지 않습니다.
        2. 가구 위나 가구 등 잔짐을 전부 치워주셔야 가구를 옮기며 시공합니다.
        3. 옮기기 힘든 가구의 경우 보이는 부분만 재단되어 시공될 수 있습니다.
        4. 가구, 바닥 등 미리 비닐 또는 덮을 것으로 보양을 진행해주세요.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header>질문 #3</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header>질문 #4</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header>질문 #5</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </Accordion.Body>
      </Accordion.Item>
      </Accordion>
      </Tab>
 
    </Tabs>
    </div>
    </Container>
    </>
  );
}

export default QnA;