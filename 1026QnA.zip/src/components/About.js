import React from "react";
import Container from 'react-bootstrap/Container';

const url = "https://www.kcc.go.kr/user.do";
const About = () => {
    return(
        <div>
        <Container>

            <h1>회사소개(About)</h1>
            <p>이 프로젝트는 리액트 라우터 기초를 실행해 보는 예제 프로젝트입니다!</p>
            <br />
                <button onClick={()=>{window.open(url)}} >방송통신위원회 웹사이트 바로가기</button>
        </Container>
        </div>
    );
};
export default About;