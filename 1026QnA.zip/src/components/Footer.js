import React from "react";
import Container from 'react-bootstrap/Container';
import "../css/common.css";
import "../css/footer.css";


// const url = "https://www.kcc.go.kr/user.do";

const Footer = () => {
    return(
        <div id="f_bg">
            <Container>
                <br />
                <hr />
                
                {/* <h1><img className="m2" width="100px" height="100px" src='/images/logo2.png' alt='로고이미지' /></h1> */}
                <br />
                <div class="container">
                    <div class="row">
                        <div class="footer__addr col-md-3 col-sm-3 col-xs-12">
                            <h1 class="footer__logo"><a href="/">Moenia</a></h1>
                            
                            <h2>주소</h2>
                            
                            <address>
                            서울특별시 구로구 경인로 557 삼영빌딩 4층
                            <br />

                            <a class="footer__btn" href="mailto:madola3813@gmail.com">Email Us</a>
                            </address>
                        </div>
                        
                        <ul class="footer__nav">
                            <li class="nav__item col-md-6 col-sm-6 col-xs-12">
                                <h2 class="nav__title">Site</h2>
                                
                                <ul class="nav__ul nav__ul--extra">
                                    <li>
                                    <a href="/About">회사소개</a>
                                    </li>
                                    
                                    <li>
                                    <a href="/Location">찾아오시는길</a>
                                    </li>
                                    
                                    <li>
                                    <a href="/Service">서비스 홍보(브랜드)</a>
                                    </li>
                                    
                                    <li>
                                    <a href="/QnA">자주묻는질문</a>
                                    </li>
                                    
                                    <li>
                                    <a href="/Consult">상담문의</a>
                                    </li>

                                    <li>
                                    <a href="/Register">로그인</a>
                                    </li>
                                </ul>
                            </li>
                            
                            <li class="nav__item col-md- col-sm-6 col-xs-12">
                                <h2 class="nav__title">Info</h2>

                                <ul class="nav__ul">
                                    <li>
                                    <a href="{()=>false}">이용약관</a>
                                    </li>

                                    <li>
                                    <a href="{()=>false}">개인정보처리방침</a>
                                    </li>
                                        
                                    <li>
                                    <a href="{()=>false}">이용안내</a>
                                    </li>
                                </ul>
                            </li>              
                        </ul>                      
                        <hr />
                        <div class="col-md-8 col-sm-6 col-xs-12 copy">
                            <p class="copyright-text">Copyright &copy; 2023 All Rights Reserved by 
                            <a href="{()=>false}">Moenia</a>.
                            </p>
                        </div>

                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <ul class="social-icons">
                                <li><a class="facebook" href="{()=>false}"><i class="fa fa-facebook"></i></a></li>
                                <li><a class="twitter" href="{()=>false}"><i class="fa fa-twitter"></i></a></li>
                                <li><a class="dribbble" href="{()=>false}"><i class="fa fa-dribbble"></i></a></li>
                                <li><a class="linkedin" href="{()=>false}"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>    
                </div>
                {/* <button onClick={()=>{window.open(url)}} >방송통신위원회 웹사이트 바로가기</button> */}
                
            </Container>
        </div>
    );
};

export default Footer;