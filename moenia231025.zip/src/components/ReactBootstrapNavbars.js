import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import "../css/common.css";
import { Link } from 'react-router-dom';

// react-bootstrap/Navbar
// https://react-bootstrap.netlify.app/docs/components/navbar/

function ReactBootstrapNavbars() {
  return (
    <Navbar bg="white" expand="lg">
      <Container>
        <Navbar.Brand href="/" className='logo'><img src='/img/logo.png' alt='로고이미지' /></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto font">
            <Nav.Link href="/About">회사소개</Nav.Link>
            <NavDropdown title="상품소개" id="basic-nav-dropdown">
              <div className='eng'>
              <NavDropdown.Item href="/notice"><p>Kids</p></NavDropdown.Item>
              <NavDropdown.Item href="/freeboard"><p>Nature</p></NavDropdown.Item>
              <NavDropdown.Item href="/communityboard"><p>Modern</p></NavDropdown.Item>              
              </div>
            </NavDropdown>
            <Nav.Link href="/board">자유게시판</Nav.Link>
            <Nav.Link href="/Locaction">찾아오시는길</Nav.Link>
            <Nav.Link href="/Consultation">1:1 상담문의</Nav.Link>
          </Nav>
          <Button variant="outline-secondary" href='/Login'>로그인</Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default ReactBootstrapNavbars;