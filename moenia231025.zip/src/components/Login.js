import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';

class Login extends Component {
    render() {
        return (
            <Container>
                안녕
            </Container>
        );
    }
}

export default Login;