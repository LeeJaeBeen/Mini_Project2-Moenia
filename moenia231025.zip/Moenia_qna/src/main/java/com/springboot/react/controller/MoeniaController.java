package com.springboot.react.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.react.impl.MoeniaService;
import com.springboot.react.model.MoeniaModel;

@RestController
public class MoeniaController {

	@Autowired
	private MoeniaService moeniaService;
	
	@RequestMapping(value = "insertProcess.do")
	public void insertProcess(MoeniaModel moenia) {
		moeniaService.save(moenia);
	}
	
}
