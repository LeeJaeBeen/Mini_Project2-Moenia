package com.springboot.react.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.springboot.react.model.MoeniaModel;



@Repository
public interface MoeniaRepository extends CrudRepository<MoeniaModel, Integer> {

	MoeniaModel save(MoeniaModel moenia);

}

