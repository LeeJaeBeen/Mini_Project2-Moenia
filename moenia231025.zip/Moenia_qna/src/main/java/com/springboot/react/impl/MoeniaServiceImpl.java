package com.springboot.react.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.react.model.MoeniaModel;
import com.springboot.react.repository.MoeniaRepository;

@Service("MoeniaService")
public class MoeniaServiceImpl implements MoeniaService {

    @Autowired
    private MoeniaRepository dao;
    
    // 글 등록
    public void save(MoeniaModel moenia) {
        dao.save(moenia);
    }

	

	
}
