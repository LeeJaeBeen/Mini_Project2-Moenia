package com.springboot.react.impl;

import com.springboot.react.model.MoeniaModel;

public interface MoeniaService {

	void save(MoeniaModel moenia);
	
}
