package com.springboot.react.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "Moenia_qna")
public class MoeniaModel {
	
	@Id
	@GeneratedValue
	@Column(name = "moenia_id")
	private int moeniaId;
	
	@Column(name = "moenia_title")
	private String moeniaTitle;
	
	@Column(name = "moenia_content")
	private String moeniaContent;	

}
