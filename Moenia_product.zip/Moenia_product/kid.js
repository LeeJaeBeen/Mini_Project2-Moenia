import React from "react";
import ReactBootstrapNavbars from "./ReactBootstrapNavbars";
import Footer from "./Footer";
import { Container } from "reactstrap";
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import '../css/kid.css'

const kid = () => {
    return (
        <div>
            <ReactBootstrapNavbars />
            <Container>
                <Tabs
                    defaultActiveKey="profile"
                    id="fill-tab-example"
                    className="mb-3"
                    fill
                >
                    <Tab eventKey="home" title="Kid">
                        <Row>
                            <Col lg className="kid1 m20"></Col>
                            <Col lg className="kid2 m20"></Col>
                            <Col lg className="kid3 m20"></Col>
                        </Row>
                        <Row>
                            <Col lg className="kid4 m20"></Col>
                            <Col lg className="kid5 m20"></Col>
                            <Col lg className="kid6 m20"></Col>
                        </Row>
                        <Row>
                            <Col lg className="kid7 m20"></Col>
                            <Col lg className="kid8 m20"></Col>
                            <Col lg className="kid9 m20"></Col>
                        </Row>
                    </Tab>
                    <Tab eventKey="profile" title="Natrue">
                        <Row>
                            <Col lg className="Nature1 m20"></Col>
                            <Col lg className="Nature2 m20"></Col>
                            <Col lg className="Nature3 m20"></Col>
                        </Row>
                        <Row>
                            <Col lg className="Nature4 m20"></Col>
                            <Col lg className="Nature5 m20"></Col>
                            <Col lg className="Nature6 m20"></Col>
                        </Row>
                        <Row>
                            <Col lg className="Nature7 m20"></Col>
                            <Col lg className="Nature8 m20"></Col>
                            <Col lg className="Nature9 m20"></Col>
                        </Row>
                    </Tab>
                    <Tab eventKey="longer-tab" title="Modern">
                        <Row>
                            <Col lg className="Modern1 m20"></Col>
                            <Col lg className="Modern2 m20"></Col>
                            <Col lg className="Modern3 m20"></Col>
                        </Row>
                        <Row>
                            <Col lg className="Modern4 m20"></Col>
                            <Col lg className="Modern5 m20"></Col>
                            <Col lg className="Modern6 m20"></Col>
                        </Row>
                        <Row>
                            <Col lg className="Modern7 m20"></Col>
                            <Col lg className="Modern8 m20"></Col>
                            <Col lg className="Modern9 m20"></Col>
                        </Row>
                    </Tab>
                </Tabs>
            </Container>
            <Footer />
        </div>
    );
};
export default kid;